CREATE DATABASE culoBotella;
USE culoBotella;
CREATE TABLE proveedores(
	id INT NOT NULL auto_increment,
    nombre VARCHAR(25) NOT NULL,
    dir_id INT NOT NULL,
    telefono INT,
    fax INT,
    nif VARCHAR(9),
    PRIMARY KEY (id),
	FOREIGN KEY (dir_id) REFERENCES direcciones (id)
    );
INSERT INTO proveedores (nombre, dir_id, nif)
	VALUES ( "Juan", 1, "1234A"), ( "Pedro", 2, "5678B"), ( "Maria", 3, "9012C"),  ("Eva", 4, "1111D");
SELECT * FROM proveedores;
-- DROP TABLE proveedores;
CREATE TABLE gafas_vendidas(
	id INT NOT NULL auto_increment,
    cliente_id INT NOT NULL,
	marca_id INT NOT NULL,
	grad_izq DECIMAL(4,2),
	grad_der DECIMAL(4,2),
	tipo_mont_id INT NOT NULL,
	color_mont VARCHAR(9),
	color_der VARCHAR(9),
	color_izq VARCHAR(9),
    precio DECIMAL(8,2) NOT NULL,
    vendor_id INT NOT NULL,
	PRIMARY KEY (id),
    FOREIGN KEY (marca_id) REFERENCES marcas(id),
    FOREIGN KEY (tipo_mont_id) REFERENCES tipos_montura(id),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    FOREIGN KEY (vendor_id) REFERENCES vendors(id)
	);
INSERT INTO gafas_vendidas (cliente_id, marca_id, tipo_mont_id, precio, vendor_id)
	VALUES ( 1, 2, 1, 120, 1), ( 1, 3, 2, 134.50,1), (2, 2, 2, 99.99,3), (2, 1, 3, 112, 2);
SELECT * FROM gafas_vendidas;
-- DROP TABLE gafas_vendidas;
CREATE TABLE tipos_montura (
	id INT NOT NULL auto_increment,
	tipo_mont VARCHAR(25) NOT NULL,
	PRIMARY KEY (id)
	);
INSERT INTO tipos_montura (tipo_mont)
	VALUES ( "flotante"), ( "pasta"), ( "metalica");
SELECT * FROM tipos_montura;
-- DROP TABLE tipos_montura;
CREATE TABLE marcas (
	id INT NOT NULL auto_increment,
	marca VARCHAR(25) NOT NULL,
    prov_id INT NOT NULL,
	PRIMARY KEY (id),
    FOREIGN KEY (prov_id) REFERENCES proveedores (id)
	);
INSERT INTO marcas (marca, prov_id)
	VALUES ( "oakley", 1), ( "rayban", 1), ( "adidas", 3), ( "nike", 2);
SELECT * FROM marcas;
-- DROP TABLE marcas;
CREATE TABLE direcciones(
	id INT NOT NULL auto_increment,
    calle VARCHAR(25) NOT NULL,
    numero INT NOT NULL,
    piso TINYINT,
    puerta TINYINT,
    ciudad VARCHAR(20) NOT NULL,
    zip_code INT NOT NULL,
    PRIMARY KEY (id)
    );
INSERT INTO direcciones ( calle, numero, ciudad, zip_code)
	VALUES ("Gran Via", 1000, "Barcelona", 08020), ("Muntaner", 100, "Barcelona", 08060), ("Balmes", 33, "Barcelona", 08010), ("Gran Via", 55, "Madrid", 28004);
SELECT * FROM direcciones;
-- DROP TABLE direcciones;
CREATE TABLE clientes(
	id INT NOT NULL auto_increment,
    nombre VARCHAR(25) NOT NULL,
    dir_id INT NOT NULL,
    telefono INT,
    email VARCHAR(25),
    fecha_alta DATE NOT NULL,
    recomend_id INT,
    PRIMARY KEY (id),
    FOREIGN KEY (dir_id) REFERENCES direcciones(id)
    );
INSERT INTO clientes (nombre, dir_id, fecha_alta)
	VALUES ("Pol", 1, CURDATE()), ("Pere", 2, CURDATE());
SELECT * FROM clientes;
-- DROP TABLE clientes;
CREATE TABLE vendors (
	id INT NOT NULL auto_increment,
	nombre VARCHAR(25) NOT NULL,
	PRIMARY KEY (id)
	);
INSERT INTO vendors (nombre)
	VALUES ("Juanito"), ("Luis"), ("Ana");
SELECT * FROM vendors;
-- DROP TABLE vendors;
SELECT g.id as factura,  c.id as num_cliente, c.nombre, g.tipo_mont_id, g.precio, g.vendor_id 
FROM gafas_vendidas g
JOIN clientes c
	ON g.cliente_id = c.id
WHERE c.nombre = "Pol";
SELECT g.id as factura, g.vendor_id, v.nombre as vendor_name, g.tipo_mont_id,  g.marca_id, g.precio
FROM gafas_vendidas g
JOIN vendors v
	ON g.vendor_id = v.id
WHERE v.nombre = "Ana";
SELECT g.id as factura, g.precio, g.marca_id, m.marca, p.nombre as proveedor_name
FROM gafas_vendidas g
JOIN marcas m
	ON g.marca_id = m.id
JOIN proveedores p
	ON m.prov_id = p.id;





    