CREATE DATABASE pizzeria;
USE pizzeria;
CREATE TABLE provincias(
	id INT NOT NULL auto_increment,
    nombre VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);
INSERT INTO provincias (nombre)
	VALUES ("Barcelona"), ("Madrid"), ("Sevilla");
SELECT * FROM provincias;
-- DROP TABLE provincias;
CREATE TABLE ciudades(
	id INT NOT NULL auto_increment,
    nombre VARCHAR(25) NOT NULL,
    provincia_id INT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (provincia_id) REFERENCES provincias(id)
);
INSERT INTO ciudades (nombre, provincia_id)
	VALUES ("Barcelona", 1 ), ("Madrid", 2 ), ("Sabadell", 1 ), ("Pinto", 2 );
SELECT * FROM ciudades;
-- DROP TABLE ciudades;
CREATE TABLE direcciones(
	id INT NOT NULL auto_increment,
    ciudad_id INT NOT NULL,
    calle VARCHAR(25) NOT NULL,
    numero INT NOT NULL,
    piso TINYINT,
    puerta TINYINT,
	zip_code INT,
    PRIMARY KEY (id),
    FOREIGN KEY (ciudad_id) REFERENCES ciudades(id)
);
INSERT INTO direcciones (ciudad_id, calle, numero)
	VALUES (1, "Gran via", 1000 ), (1, "Muntaner", 100 ), (1, "Balmes", 55 ), (1, "Navas", 250 ), (2, "Alcala", 125), (1, "Aribau", 88), (2, "La Castellana", 101);
SELECT *FROM direcciones;
-- DROP TABLE direcciones;
CREATE TABLE tiendas(
	id INT NOT NULL auto_increment,
    dir_id INT NOT NULL,
    PRIMARY KEY (id),
	FOREIGN KEY (dir_id) REFERENCES direcciones(id)
);
INSERT INTO tiendas (dir_id)
	VALUES (6), (7);
SELECT * FROM tiendas;
-- DROP TABLE tiendas;
CREATE TABLE tipo_empleado(
	id INT NOT NULL auto_increment,
    tipo VARCHAR(20) NOT NULL,
    PRIMARY KEY (id)
);
INSERT INTO tipo_empleado (tipo)
	VALUES ("Repartidor"), ("Cocinero");
SELECT * FROM tipo_empleado;
CREATE TABLE empleados(
	id INT NOT NULL auto_increment,
    nombre VARCHAR(25) NOT NULL,
    apellidos VARCHAR(25),
    nif VARCHAR(9),
    telefono INT,
    tipo_empleado_id INT,
    tienda_id INT,
    PRIMARY KEY (id),
    FOREIGN KEY (tienda_id) REFERENCES tiendas(id),
    FOREIGN KEY (tipo_empleado_id) REFERENCES tipo_empleado(id)
);
INSERT INTO empleados (nombre, tipo_empleado_id, tienda_id)
	VALUES ("Luis", 1, 1), ("Eva", 1, 1), ("Sebastian", 2, 1), ("Ana", 2, 2), ("Antonio", 1, 2);
SELECT * FROM empleados;
-- DROP TABLE empleados;
CREATE TABLE clientes(
	id INT NOT NULL auto_increment,
    nombre VARCHAR(25) NOT NULL,
    apellidos VARCHAR(25),
    telefono INT,
    dir_id INT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (dir_id) REFERENCES direcciones(id)
);
INSERT INTO clientes (nombre, dir_id)
	VALUES ("Joan", 1),  ("Pere", 3),  ("Ana", 2),  ("Marta", 4), ("Pedro", 5);
SELECT * FROM clientes;
-- DROP TABLE clientes;
CREATE TABLE tipo_pedidos(
	id INT NOT NULL auto_increment,
	tipo VARCHAR(25) NOT NULL,
	PRIMARY KEY (id)
);
INSERT INTO tipo_pedidos (tipo)
	VALUES ("Domicilio"),  ("Recoger en tienda");
SELECT * FROM tipo_pedidos;
-- DROP TABLE tipo_pedidos;
CREATE TABLE pedidos(
	id INT NOT NULL auto_increment,
    cliente_id INT NOT NULL,
    tipo_pedido_id INT NOT NULL,
    fecha_hora DATETIME,
    precio_tot DECIMAL(8,2) NOT NULL,
    tienda_id INT NOT NULL,
    repartidor_id INT NOT NULL,
    salida_prod DATETIME,
    PRIMARY KEY (id),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    FOREIGN KEY (tipo_pedido_id) REFERENCES tipo_pedidos(id),
    FOREIGN KEY (tienda_id) REFERENCES tiendas(id),
    FOREIGN KEY (repartidor_id) REFERENCES empleados(id)
);
INSERT INTO pedidos (cliente_id, precio_tot, tienda_id, tipo_pedido_id, repartidor_id, salida_prod)
	VALUES (1, 100.15, 1, 1, 1, NOW()), (3, 44.55, 1, 1, 2, NOW()), (2, 66.50, 1, 1, 1, NOW()), (1, 88.30, 1, 1, 2, NOW()), (5, 77.30, 2, 1, 5, NOW());
SELECT * FROM pedidos;
-- DROP TABLE pedidos;
CREATE TABLE tipos_prod(
	id INT NOT NULL auto_increment,
    nombre VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);
INSERT INTO tipos_prod (nombre)
	VALUES ("Pizza"), ("Hamburguesa"), ("Bebida");
SELECT * FROM tipos_prod;
-- DROP TABLE tipos_prod;
CREATE TABLE cat_pizza(
	id INT NOT NULL auto_increment,
    nombre VARCHAR(25) NOT NULL,
    PRIMARY KEY(id)
);
INSERT INTO cat_pizza (nombre)
	VALUES ("Vegana"), ("Carnivora"), ("Regular");
SELECT * FROM cat_pizza;
-- DROP TABLE cat_pizza;
CREATE TABLE productos(
	id INT NOT NULL auto_increment,
    nombre VARCHAR(25) NOT NULL,
    descripcion VARCHAR(35),
    -- imagen contendria ruta de ubicacion de imagen
    imagen VARCHAR(25),
    precio DECIMAL(8,2) NOT NULL,
    tipo_prod_id INT NOT NULL,
    cat_pizza_id INT,
    PRIMARY KEY (id),
	FOREIGN KEY (tipo_prod_id) REFERENCES tipos_prod(id),
    FOREIGN KEY (cat_pizza_id) REFERENCES cat_pizza(id)
);
INSERT INTO productos (nombre, precio, tipo_prod_id, cat_pizza_id)
	VALUES ("Coke", 3, 3, null),  ("Agua", 2, 3, null),  ("Cerveza", 3, 3, null),  ("Hawaiana", 7, 1, 3),  ("Barbacoa", 8, 1, 2),  ("Chesseburger", 5, 2, null);
SELECT * FROM productos;
-- DROP TABLE productos;
CREATE TABLE ped_prod(
	ped_id INT NOT NULL,
    prod_id INT NOT NULL,
    cantidad INT NOT NULL,
    subtotal DECIMAL(8,2),
    PRIMARY KEY (ped_id, prod_id),
    FOREIGN KEY (ped_id) REFERENCES pedidos(id),
    FOREIGN KEY (prod_id) REFERENCES productos(id)
);
INSERT INTO ped_prod (ped_id, prod_id, cantidad)
	VALUES (1, 1, 2),  (1, 2, 4),  (1, 4, 2), (2, 2, 2),  (2, 3, 6),  (2, 5, 2), (3, 2, 6),  (3, 6, 4), (4, 1, 4),  (4, 4, 1),  (5, 3, 6), (5, 4, 1);
SELECT * FROM ped_prod;
-- DROP TABLE ped_prod;
SELECT t.id as tienda_id, pr.nombre, pp.cantidad
FROM ped_prod pp
JOIN pedidos p
	ON pp.ped_id = p.id
JOIN tiendas t
	ON p.tienda_id = t.id
JOIN direcciones d
	ON t.dir_id = d.id
JOIN productos pr
	ON pp.prod_id = pr.id
WHERE d.ciudad_id = 1 AND pr.tipo_prod_id = 3;
SELECT p.id as pedido_id, p.cliente_id, p.precio_tot, e.id as empleado_id, e.nombre 
FROM pedidos p
JOIN empleados e
	ON p.repartidor_id = e.id
WHERE e.id = 1;


