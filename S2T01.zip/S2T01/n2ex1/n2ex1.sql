CREATE DATABASE youtube;
USE youtube;
CREATE TABLE usuarios(
	user_id INT NOT NULL auto_increment,
    u_name VARCHAR(25) NOT NULL,
    pass VARCHAR(25) NOT NULL,
    email VARCHAR(25),
    dob DATE,
    -- "M" masculino "F" femenino
    sexo VARCHAR(1),
    pais VARCHAR(25),
    zip_code INT,
    PRIMARY KEY (user_id)
);
INSERT INTO usuarios (u_name, pass)
	VALUES ("Ana", "1234"), ("Luis", "5678"), ("Eva", "0123"), ("Teo", "4567"), ("Isa", "2468"), ("Toni", "1357");
SELECT * FROM usuarios;
-- DROP TABLE usuarios;
CREATE TABLE states(
	state_id INT NOT NULL auto_increment,
    state VARCHAR(15) NOT NULL,
    PRIMARY KEY (state_id)
);
INSERT INTO states (state)
	VALUES ("Publico"), ("Oculto"), ("Privado");
SELECT * FROM states;
-- DROP TABLE states;
CREATE TABLE videos(
	video_id INT NOT NULL auto_increment,
    user_id INT NOT NULL,
    state_id INT NOT NULL,
    titulo VARCHAR(25) NOT NULL,
    descripcion VARCHAR(35),
    -- entero corresp a la resolucion: 480, 720, 1080, 1440.
    size INT,
    -- ruta del archivo
    archivo VARCHAR(35),
    duracion TIME,
    -- ruta de la miniatura.
    thumbnail VARCHAR(35),
    visual INT,
    likes INT,
    dislikes INT,
    creacion DATETIME,
    PRIMARY KEY (video_id),
    FOREIGN KEY (user_id) REFERENCES usuarios(user_id),
    FOREIGN KEY (state_id) REFERENCES states(state_id)
);
INSERT INTO videos (user_id, state_id, titulo)
	VALUES (1, 1, "La conga"), (1, 1, "La lambada"), (1, 1, "El twist"), (2, 1, "La Jota");
SELECT * FROM videos;
-- DROP TABLE videos;
CREATE TABLE etiquetas(
	tag_id INT NOT NULL auto_increment,
    video_id INT NOT NULL,
    nombre VARCHAR(25) NOT NULL,
    PRIMARY KEY (tag_id),
	FOREIGN KEY (video_id) REFERENCES videos(video_id)
);
INSERT INTO etiquetas (video_id, nombre)
	VALUES (1, "el baile"), (2, "que calor"), (3, "que toston"), (4, "los maños");
SELECT * FROM etiquetas;
-- DROP TABLE etiquetas;
CREATE TABLE canales(
	canal_id INT NOT NULL auto_increment,
    user_id INT NOT NULL,
    c_name VARCHAR(25) NOT NULL,
    c_desc VARCHAR(35),
    creacion DATETIME,
    PRIMARY KEY (canal_id),
    FOREIGN KEY (user_id) REFERENCES usuarios(user_id)
);
INSERT INTO canales (user_id, c_name)
	VALUES (1, "Bailes"), (2, "Que bailes!");
SELECT * FROM canales;
-- DROP TABLE canales;
CREATE TABLE users_suscritos_canales(
	user_id INT NOT NULL,
    canal_id INT NOT NULL,
	PRIMARY KEY (user_id, canal_id),
    FOREIGN KEY (user_id) REFERENCES usuarios(user_id),
    FOREIGN KEY (canal_id) REFERENCES canales(canal_id)
);
INSERT INTO users_suscritos_canales (user_id, canal_id)
	VALUES (1, 2), (2, 1), (3, 1), (4, 1), (5, 1), (6, 2);
SELECT * FROM users_suscritos_canales;
-- DROP TABLE users_suscritos_canales;
CREATE TABLE users_likes_videos(
	user_id INT NOT NULL,
    video_id INT NOT NULL,
    likes DATETIME,
	PRIMARY KEY (user_id, video_id),
    FOREIGN KEY (user_id) REFERENCES usuarios(user_id),
    FOREIGN KEY (video_id) REFERENCES videos(video_id)
);
INSERT INTO users_likes_videos (user_id, video_id)
	VALUES (1, 1), (2, 1), (4, 1), (1, 2), (2, 2), (3, 2), (1, 3), (1, 4), (2, 4), (4, 4);
SELECT * FROM users_likes_videos;
-- DROP TABLE users_likes_videos;
CREATE TABLE users_dislikes_videos(
	user_id INT NOT NULL,
    video_id INT NOT NULL,
    dislikes DATETIME,
	PRIMARY KEY (user_id, video_id),
    FOREIGN KEY (user_id) REFERENCES usuarios(user_id),
    FOREIGN KEY (video_id) REFERENCES videos(video_id)
);
INSERT INTO users_dislikes_videos (user_id, video_id)
	VALUES (5, 3);
SELECT * FROM users_dislikes_videos;
-- DROP TABLE users_dislikes_videos;
CREATE TABLE playlists(
	pl_id INT NOT NULL auto_increment,
    user_id INT NOT NULL,
	pl_name VARCHAR(35) NOT NULL,
    creacion DATETIME,
    state_id INT,
    PRIMARY KEY (pl_id),
    FOREIGN KEY (state_id) REFERENCES states(state_id),
    FOREIGN KEY (user_id) REFERENCES usuarios(user_id)
);
INSERT INTO playlists (pl_name, user_id, creacion)
	VALUES ("Baila", 1, NOW()), ("Marcha", 3, NOW());
SELECT * FROM playlists;
-- DROP TABLE playlists;
CREATE TABLE playlists_have_videos(
	pl_id INT NOT NULL,
    video_id INT NOT NULL,
	PRIMARY KEY (pl_id, video_id),
    FOREIGN KEY (pl_id) REFERENCES playlists(pl_id),
    FOREIGN KEY (video_id) REFERENCES videos(video_id)
);
INSERT INTO playlists_have_videos (pl_id, video_id)
	VALUES (1, 1), (1, 2), (1, 3), (1, 4), (2, 1), (2, 4);
SELECT * FROM playlists_have_videos;
-- DROP TABLE playlists_have_videos;
CREATE TABLE users_coments_videos(
	coment_id INT NOT NULL auto_increment,
    user_id INT NOT NULL,
    video_id INT NOT NULL,
    comentario VARCHAR(120),
	creacion DATETIME,
    PRIMARY KEY (coment_id),
    FOREIGN KEY (user_id) REFERENCES usuarios(user_id),
    FOREIGN KEY (video_id) REFERENCES videos(video_id)
);
INSERT INTO users_coments_videos (user_id, video_id, comentario)
	VALUES (1, 1, "Que buena soy"), (2, 1, "Ole"), (1, 1, "entreno mucho"), (5, 1, "Muy bien"), (3, 2, "Que arte"), (5, 3, "Oju");
SELECT * FROM users_coments_videos;
-- DROP TABLE users_coments_videos;
CREATE TABLE users_likes_coments(
	user_id INT NOT NULL,
    coment_id INT NOT NULL,
    likes DATETIME,
	PRIMARY KEY (user_id, coment_id),
    FOREIGN KEY (user_id) REFERENCES usuarios(user_id),
    FOREIGN KEY (coment_id) REFERENCES users_coments_videos(coment_id)
);
INSERT INTO users_likes_coments (user_id, coment_id)
	VALUES (1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (2, 5);
SELECT * FROM users_likes_coments ;
-- DROP TABLE users_likes_coments ;
CREATE TABLE users_dislikes_coments(
	user_id INT NOT NULL,
    coment_id INT NOT NULL,
    dislikes DATETIME,
	PRIMARY KEY (user_id, coment_id),
    FOREIGN KEY (user_id) REFERENCES usuarios(user_id),
    FOREIGN KEY (coment_id) REFERENCES users_coments_videos(coment_id)
);
INSERT INTO users_dislikes_coments (user_id, coment_id)
	VALUES (1, 6);
SELECT * FROM users_dislikes_coments ;
-- DROP TABLE users_dislikes_coments ;


